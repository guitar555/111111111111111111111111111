from bot import MusicBot


def main():
    bot = MusicBot()
    bot.run()


if __name__ == "__main__":
    main()